<?php

return array(
    'plugin_homepage' => 'https://supsystic.com/plugins/data-tables-generator-plugin/',
    'campaign'        => 'data-tables',
);