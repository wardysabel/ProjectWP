(function ($, app) {
	$(document).ready(function () {
		app.initTablesOnPage();
	});
}(window.jQuery, window.supsystic.Tables));
