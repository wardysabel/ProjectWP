ALTER TABLE `%prefix%tables` 
    ADD COLUMN `meta` TEXT NULL AFTER `created_at`;