(function($){
	$(".chosen-select").chosen();
})(jQuery);